<?php
include('widgets/header.php');
include('widgets/sidebar.php');
?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Payment Reports</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Payment Reports</li>
                        </ol>
                        <hr>
                        <br>
                    </div>
                </main>
               
<?php
include('widgets/footer.php');
?>