<?php
include('widgets/header.php');
header("Location: dashboard.php");
?>
