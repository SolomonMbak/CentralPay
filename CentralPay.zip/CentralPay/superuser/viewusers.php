<title>View Users - CentralPay</title>
<?php
include('widgets/header.php');
include('widgets/sidebar.php');
?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">View Users</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">View Users</li>
                        </ol>
                        <hr>
                        <br>
<table class="table table-striped">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <?php
            if (isset($_POST["btn_search"])) {

                $search = "{$_POST['btn_search']}";
                $stmt = mysqli_query($conn,"SELECT user_first_name, user_other_names, user_email, user_phone, user_level, user_reg_number, user_state_of_origin, user_status FROM master_user_info WHERE user_first_name OR user_reg_number like ? order by user_first_name asc");
                $stmt->bind_param("s", $search);
                $stmt->execute();
                $result = $stmt->get_result();

            }else{
              $stmt = mysqli_query($conn,"SELECT user_first_name, user_other_names, user_email, user_phone, user_level, user_reg_number, user_state_of_origin, user_status FROM master_user_info order by user_first_name asc");
              $stmt->execute();
              $result = $stmt->get_result();
            }

            while ($row = $result->fetch_assoc()) {
              echo '<tr>';
              echo 
              '<td>'.$row["user_first_name"]. " ". $row["user_first_name"] . "</td>
               <td>".$row["user_email"]."</td>
               <td>".$row["user_phone"]."</td>
               <td>".$row["user_level"]."</td>
               <td>".$row["user_reg_number"]."</td>
               <td>".$row["user_state_of_origin"]."</td>
               <td>".$row["user_status"]."</td>
               <td><a href='?delete_id=".$row["top_cat_id"]."' onclick=\"return confirm('Are you sure you want to permanently delete this record?');\"'> Delete</a></td>";
              echo '</tr>';
            }
            ?>
    </tr>
  </tbody>
</table>
</div>
</main>
               
<?php
include('widgets/footer.php');
?>